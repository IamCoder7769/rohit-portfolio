export interface ThemePalette {
  id: 'white-canvas-green-cards' | 'ivory-green-tangerine' | 'emerald-obsidian' | 'indigo-violet' | 'tonal-slate' | 'carbon-amber' | 'cyber-dusk' | 'nordic-light' | 'sage-olive';
  name: string;
  badge: string;
  description: string;
  bgMain: string;
  bgCard: string;
  chipBg: string;
  borderMain: string;
  borderSubtle: string;
  primaryAccent: string;
  primaryHover: string;
  primaryText: string;
  goldAccent: string;
  goldHover?: string;
  textMain: string;
  textBody: string;
  textMuted: string;
  pillBg: string;
  pillBorder: string;
  pillText: string;
  chipBorder: string;
  iconBoxBg: string;
  isDark?: boolean;
}

// 1. BRIGHT WHITE + VIBRANT VIOLET (DEFAULT)
export const WHITE_CANVAS_GREEN_CARDS_PALETTE: ThemePalette = {
  id: 'white-canvas-green-cards',
  name: 'Bright White & Vibrant Violet',
  badge: 'White · Violet',
  description: 'Clean white canvas with vibrant violet accents and soft lavender cards.',
  bgMain: '#FFFFFF',
  bgCard: '#FDF4FF',
  chipBg: '#F3E8FF',
  borderMain: '#E9D5FF',
  borderSubtle: '#F3E8FF',
  primaryAccent: '#ccc5b9',
  primaryHover: '#b5aea8',
  primaryText: '#FFFFFF',
  goldAccent: '#EC4899',
  goldHover: '#DB2777',
  textMain: '#1A0533',
  textBody: '#4B5563',
  textMuted: '#9CA3AF',
  pillBg: '#F3E8FF',
  pillBorder: '#D8B4FE',
  pillText: '#b5aea8',
  chipBorder: '#D8B4FE',
  iconBoxBg: '#F3E8FF',
  isDark: false,
};

// 2. WARM WHITE + INDIGO
export const IVORY_GREEN_TANGERINE_PALETTE: ThemePalette = {
  id: 'ivory-green-tangerine',
  name: 'Warm White & Indigo',
  badge: 'Warm · Indigo',
  description: 'Warm off-white canvas with deep indigo accents and amber highlights.',
  bgMain: '#FAFAF9',
  bgCard: '#FFFFFF',
  chipBg: '#EEF2FF',
  borderMain: '#C7D2FE',
  borderSubtle: '#E5E7EB',
  primaryAccent: '#4F46E5',
  primaryHover: '#4338CA',
  primaryText: '#FFFFFF',
  goldAccent: '#F59E0B',
  goldHover: '#D97706',
  textMain: '#ccc5b9',
  textBody: '#b5aea8',
  textMuted: '#6B7280',
  pillBg: '#EEF2FF',
  pillBorder: '#A5B4FC',
  pillText: '#4338CA',
  chipBorder: '#C7D2FE',
  iconBoxBg: '#EEF2FF',
  isDark: false,
};

// 3. DARK NAVY + CYAN
export const EMERALD_OBSIDIAN_PALETTE: ThemePalette = {
  id: 'emerald-obsidian',
  name: 'Dark Navy & Cyan',
  badge: 'Navy · Cyan',
  description: 'Deep navy dark canvas with electric cyan glow accents.',
  bgMain: '#0A0F1E',
  bgCard: '#ccc5b9',
  chipBg: '#1E293B',
  borderMain: '#1E3A5F',
  borderSubtle: '#1E293B',
  primaryAccent: '#38BDF8',
  primaryHover: '#0EA5E9',
  primaryText: '#0A0F1E',
  goldAccent: '#F59E0B',
  goldHover: '#D97706',
  textMain: '#F1F5F9',
  textBody: '#CBD5E1',
  textMuted: '#94A3B8',
  pillBg: '#0C2233',
  pillBorder: '#0369A1',
  pillText: '#38BDF8',
  chipBorder: '#1E3A5F',
  iconBoxBg: '#1E293B',
  isDark: true,
};

// 4. DARK + VIOLET
export const INDIGO_VIOLET_PALETTE: ThemePalette = {
  id: 'indigo-violet',
  name: 'Dark & Electric Violet',
  badge: 'Dark · Violet',
  description: 'Deep cosmic dark with electric violet and rose pink highlights.',
  bgMain: '#09090F',
  bgCard: '#12121E',
  chipBg: '#1A1A2E',
  borderMain: '#2D2B55',
  borderSubtle: '#1E1E35',
  primaryAccent: '#8B5CF6',
  primaryHover: '#ccc5b9',
  primaryText: '#FFFFFF',
  goldAccent: '#EC4899',
  goldHover: '#DB2777',
  textMain: '#F8FAFC',
  textBody: '#CBD5E1',
  textMuted: '#94A3B8',
  pillBg: '#1E1B4B',
  pillBorder: '#3730A3',
  pillText: '#A78BFA',
  chipBorder: '#2D2B55',
  iconBoxBg: '#1A1730',
  isDark: true,
};

// 5. DARK + AMBER
export const CARBON_AMBER_PALETTE: ThemePalette = {
  id: 'carbon-amber',
  name: 'Dark & Warm Amber',
  badge: 'Dark · Amber',
  description: 'Pure carbon black with warm amber gold accents.',
  bgMain: '#0A0A0B',
  bgCard: '#131316',
  chipBg: '#1C1C22',
  borderMain: '#2A2A35',
  borderSubtle: '#1F1F28',
  primaryAccent: '#F59E0B',
  primaryHover: '#D97706',
  primaryText: '#0A0A0B',
  goldAccent: '#10B981',
  goldHover: '#059669',
  textMain: '#FAFAFA',
  textBody: '#D4D4D8',
  textMuted: '#A1A1AA',
  pillBg: '#292207',
  pillBorder: '#78350F',
  pillText: '#FCD34D',
  chipBorder: '#2A2A35',
  iconBoxBg: '#1C1C22',
  isDark: true,
};

// 6. DARK NAVY + BLUE
export const CYBER_DUSK_PALETTE: ThemePalette = {
  id: 'cyber-dusk',
  name: 'Midnight Navy & Blue',
  badge: 'Midnight · Blue',
  description: 'Deep midnight navy with electric blue and rose red accents.',
  bgMain: '#060B18',
  bgCard: '#0D1526',
  chipBg: '#142035',
  borderMain: '#1E3358',
  borderSubtle: '#142035',
  primaryAccent: '#3B82F6',
  primaryHover: '#2563EB',
  primaryText: '#FFFFFF',
  goldAccent: '#F43F5E',
  goldHover: '#E11D48',
  textMain: '#F8FAFC',
  textBody: '#CBD5E1',
  textMuted: '#94A3B8',
  pillBg: '#0C1A3A',
  pillBorder: '#1E3A8A',
  pillText: '#60A5FA',
  chipBorder: '#1E3358',
  iconBoxBg: '#0F1E3A',
  isDark: true,
};

// 7. SLATE DARK + SKY
export const TONAL_SLATE_PALETTE: ThemePalette = {
  id: 'tonal-slate',
  name: 'Slate Dark & Sky Blue',
  badge: 'Slate · Sky',
  description: 'Deep slate dark with luminous sky blue and teal accents.',
  bgMain: '#0B1120',
  bgCard: '#ccc5b9',
  chipBg: '#1F2937',
  borderMain: '#b5aea8',
  borderSubtle: '#1F2937',
  primaryAccent: '#38BDF8',
  primaryHover: '#0EA5E9',
  primaryText: '#0B1120',
  goldAccent: '#34D399',
  goldHover: '#10B981',
  textMain: '#F9FAFB',
  textBody: '#D1D5DB',
  textMuted: '#9CA3AF',
  pillBg: '#0C2233',
  pillBorder: '#0369A1',
  pillText: '#38BDF8',
  chipBorder: '#b5aea8',
  iconBoxBg: '#1F2937',
  isDark: true,
};

// 8. LIGHT GRAY + COBALT
export const NORDIC_LIGHT_PALETTE: ThemePalette = {
  id: 'nordic-light',
  name: 'Light Gray & Cobalt Blue',
  badge: 'Light · Cobalt',
  description: 'Clean light gray canvas with deep cobalt blue accents.',
  bgMain: '#F1F5F9',
  bgCard: '#FFFFFF',
  chipBg: '#E0F2FE',
  borderMain: '#BAE6FD',
  borderSubtle: '#E2E8F0',
  primaryAccent: '#0284C7',
  primaryHover: '#0369A1',
  primaryText: '#FFFFFF',
  goldAccent: '#D97706',
  goldHover: '#B45309',
  textMain: '#0F172A',
  textBody: '#1E293B',
  textMuted: '#475569',
  pillBg: '#E0F2FE',
  pillBorder: '#7DD3FC',
  pillText: '#0369A1',
  chipBorder: '#BAE6FD',
  iconBoxBg: '#F0F9FF',
  isDark: false,
};

// 9. SAGE OLIVE (ORIGINAL)
export const SAGE_OLIVE_PALETTE: ThemePalette = {
  id: 'sage-olive',
  name: 'Sage & Forest Olive (Original)',
  badge: 'Original Olive',
  description: 'The original sage canvas and deep olive green theme.',
  bgMain: '#ECEFCB',
  bgCard: '#FFFFFF',
  chipBg: '#F8FAF2',
  borderMain: '#DDE2BE',
  borderSubtle: '#CFD6AA',
  primaryAccent: '#4D652F',
  primaryHover: '#3F5425',
  primaryText: '#FFFFFF',
  goldAccent: '#85754D',
  goldHover: '#6D603E',
  textMain: '#181D13',
  textBody: '#1A2014',
  textMuted: '#63715A',
  pillBg: '#E1E6BD',
  pillBorder: '#CFD6AA',
  pillText: '#354326',
  chipBorder: '#DDE2BE',
  iconBoxBg: '#F3F6EA',
  isDark: false,
};

export const AVAILABLE_THEMES = [
  WHITE_CANVAS_GREEN_CARDS_PALETTE,
  IVORY_GREEN_TANGERINE_PALETTE,
  EMERALD_OBSIDIAN_PALETTE,
  INDIGO_VIOLET_PALETTE,
  CARBON_AMBER_PALETTE,
  CYBER_DUSK_PALETTE,
  TONAL_SLATE_PALETTE,
  NORDIC_LIGHT_PALETTE,
  SAGE_OLIVE_PALETTE,
];
