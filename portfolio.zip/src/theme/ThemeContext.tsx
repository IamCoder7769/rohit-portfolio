import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  ThemePalette,
  WHITE_CANVAS_GREEN_CARDS_PALETTE,
  AVAILABLE_THEMES,
} from './themeConfig';

export type ThemeId =
  | 'white-canvas-green-cards'
  | 'ivory-green-tangerine'
  | 'emerald-obsidian'
  | 'indigo-violet'
  | 'tonal-slate'
  | 'carbon-amber'
  | 'cyber-dusk'
  | 'nordic-light'
  | 'sage-olive';

interface ThemeContextType {
  theme: ThemePalette;
  themeId: ThemeId;
  isOriginal: boolean;
  cycleNextTheme: () => void;
  revertToOriginal: () => void;
  setThemeById: (id: ThemeId) => void;
  availableThemes: ThemePalette[];
}

const ThemeContext = createContext<ThemeContextType>({
  theme: WHITE_CANVAS_GREEN_CARDS_PALETTE,
  themeId: 'white-canvas-green-cards',
  isOriginal: false,
  cycleNextTheme: () => {},
  revertToOriginal: () => {},
  setThemeById: () => {},
  availableThemes: AVAILABLE_THEMES,
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Default is the user requested palette: White background and Green cards
  const [currentId, setCurrentId] = useState<ThemeId>('white-canvas-green-cards');

  useEffect(() => {
    const root = document.documentElement;
    // Remove previous theme classes
    root.classList.remove(
      'theme-white-canvas-green-cards',
      'theme-ivory-green-tangerine',
      'theme-emerald-obsidian',
      'theme-indigo-violet',
      'theme-tonal-slate',
      'theme-carbon-amber',
      'theme-cyber-dusk',
      'theme-nordic-light',
      'theme-sage-olive'
    );
    root.classList.add(`theme-${currentId}`);
  }, [currentId]);

  const cycleNextTheme = () => {
    const ids: ThemeId[] = [
      'white-canvas-green-cards',
      'ivory-green-tangerine',
      'emerald-obsidian',
      'indigo-violet',
      'carbon-amber',
      'cyber-dusk',
      'tonal-slate',
      'nordic-light',
      'sage-olive',
    ];
    const nextIndex = (ids.indexOf(currentId) + 1) % ids.length;
    setCurrentId(ids[nextIndex]);
  };

  const revertToOriginal = () => {
    setCurrentId('sage-olive');
  };

  const setThemeById = (id: ThemeId) => {
    setCurrentId(id);
  };

  const currentTheme =
    AVAILABLE_THEMES.find((t) => t.id === currentId) || WHITE_CANVAS_GREEN_CARDS_PALETTE;

  return (
    <ThemeContext.Provider
      value={{
        theme: currentTheme,
        themeId: currentId,
        isOriginal: currentId === 'sage-olive',
        cycleNextTheme,
        revertToOriginal,
        setThemeById,
        availableThemes: AVAILABLE_THEMES,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
